# 🤖 AI Meeting Scheduler – Natural Input + Timezone Based

This AI-powered project schedules common meeting time across global team members using:

- ✅ Natural language input (e.g., "after lunch", "10am to 3pm")
- 🌍 Timezone detection using `pytz`
- 📊 Web-based UI via Streamlit
- 💡 AI fallback logic to suggest nearest slot (if exact match fails)

---

## 📁 Structure

| Folder              | Description                          |
|---------------------|--------------------------------------|
| `ai_scheduler_core/` | Backend logic for scheduling, with CLI |
| `ai_scheduler_ui/`   | Streamlit app for GUI-based interaction |

---

## 🚀 How to Run

### 🧪 CLI (core)
```bash
cd ai_scheduler_core
pip install -r requirements-core.txt
python main.py
